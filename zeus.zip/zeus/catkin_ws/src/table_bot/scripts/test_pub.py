#!/usr/bin/env python2
"""
Simple Test Publisher for MovementNode

This script reads location commands from the terminal (home, table1-4, kitchen)
and publishes a corresponding TableEntry to /table_bot/flow_entries.
Use to manually test your MovementNode.

Run:
  chmod +x test_movement_publisher.py
  rosrun table_bot test_movement_publisher.py

Type one of: home, kitchen, table1, table2, table3, table4
"""
import rospy
from table_bot.msg import TableEntry

VALID_LOCATIONS = ['home','kitchen','table1','table2','table3','table4']

def main():
    rospy.init_node('test_movement_publisher', anonymous=False)
    pub = rospy.Publisher('/table_bot/flow_entries', TableEntry, queue_size=1)
    rospy.sleep(1.0)  # wait for connections
    job_id = 1
    print("[TestMovementPublisher] Ready. Type location and Enter.")
    while not rospy.is_shutdown():
        try:
            cmd = raw_input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("Exiting.")
            break
        if cmd not in VALID_LOCATIONS:
            print("Invalid location. Valid:", ', '.join(VALID_LOCATIONS))
            continue
        entry = TableEntry()
        entry.routine_id = 'R1' if cmd == 'kitchen' or cmd.startswith('table') else 'R1'
        # For pure movement test, set table_number=0 for kitchen, >0 for tableX
        if cmd == 'kitchen':
            entry.table_number = 0
        else:
            entry.table_number = int(cmd.replace('table',''))
        entry.job_id = job_id
        entry.vacancy = True
        pub.publish(entry)
        print("Published TableEntry(job_id={}, table_number={})".format(job_id, entry.table_number))
        job_id += 1
    
if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass

