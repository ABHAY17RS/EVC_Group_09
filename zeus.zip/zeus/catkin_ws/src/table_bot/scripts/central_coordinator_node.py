#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy
from table_bot.msg import TableEntry, GoSignal

class CentralCoordinatorNode(object):
    """
    NODE0: Central coordinator for R1 (entrance) and R2 (kitchen) routines.
    Subscribes to /table_bot/table_entries and /table_bot/task_complete.
    Publishes to /table_bot/flow_entries for R1, /table_bot/r2_entries for R2,
    and /table_bot/next_task when a job finishes.
    """
    def __init__(self):
        rospy.init_node('central_coordinator_node', anonymous=False)

        self.current_job = None

        # Publishers
        self.pub_r1_flow = rospy.Publisher(
            '/table_bot/r1_entries', TableEntry, queue_size=10)
        self.pub_r2_flow = rospy.Publisher(
            '/table_bot/r2_entries', TableEntry, queue_size=10)
        self.pub_next   = rospy.Publisher(
            '/table_bot/next_task', GoSignal, queue_size=10)

        # Subscribers
        rospy.Subscriber(
            '/table_bot/table_entries', TableEntry,
            self.entries_callback, queue_size=10)
        rospy.Subscriber(
            '/table_bot/task_complete', GoSignal,
            self.complete_callback, queue_size=10)

        rospy.loginfo("[CentralCoordinator] Started, waiting for jobs...")
        rospy.spin()

    def entries_callback(self, entry):
        # Only handle one job at a time
        if self.current_job is not None:
            rospy.logwarn("[CentralCoordinator] Busy with job %d, ignoring %d",
                          self.current_job.job_id, entry.job_id)
            return

        self.current_job = entry
        rospy.loginfo("[CentralCoordinator] Got job %d (routine %s)",
                      entry.job_id, entry.routine_id)

        # Forward based on routine_id
        if entry.routine_id == 'R1':
            # Entrance routine → MovementNode directly
            entry.routine_id = 'R1'
            entry.table_number = 5
            self.pub_r1_flow.publish(entry)
            rospy.loginfo("[CentralCoordinator] Forwarded R1 job %d to /flow_entries",
                          entry.job_id)
        elif entry.routine_id == 'R2':
            # Kitchen routine → PeopleDetectionNode first
            entry.routine_id = 'R2'
            entry.table_number = 0
            self.pub_r2_flow.publish(entry)
            rospy.loginfo("[CentralCoordinator] Forwarded R2 job %d to /r2_entries",
                          entry.job_id)
        else:
            # Unknown routine → error, clear state
            rospy.logerr("[CentralCoordinator] Unknown routine '%s' for job %d",
                         entry.routine_id, entry.job_id)
            self.current_job = None

    def complete_callback(self, signal):
        # Received GoSignal from MovementNode
        if self.current_job is None:
            rospy.logwarn("[CentralCoordinator] Got completion for %d but no active job",
                          signal.job_id)
            return
        if signal.job_id != self.current_job.job_id:
            rospy.logwarn("[CentralCoordinator] Completion %d ≠ active job %d",
                          signal.job_id, self.current_job.job_id)
            return

        rospy.loginfo("[CentralCoordinator] Job %d finished", signal.job_id)
        # Notify SimulationNode it can issue the next command
        self.pub_next.publish(signal)
        rospy.loginfo("[CentralCoordinator] Published GoSignal %d to /next_task",
                      signal.job_id)
        self.current_job = None


if __name__ == '__main__':
    try:
        CentralCoordinatorNode()
    except rospy.ROSInterruptException:
        pass
