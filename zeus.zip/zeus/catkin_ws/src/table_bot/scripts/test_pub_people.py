#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy
from table_bot.msg import TableEntry

def main():
    rospy.init_node('test_pub_people', anonymous=True)
    pub = rospy.Publisher('/table_bot/r2_entries', TableEntry, queue_size=1)
    rospy.sleep(0.5)  # give publisher time to register

    print("=== PeopleDetection test publisher ===")
    print("This will send an R2 job to /table_bot/r2_entries.")
    print("Enter a positive integer job ID, or 'q' to quit.")

    while not rospy.is_shutdown():
        inp = raw_input("Enter job_id (or 'q'): ").strip()
        if inp.lower() in ('q','quit','exit'):
            print("Exiting test publisher.")
            break
        if not inp.isdigit():
            print("  ❌ please enter a valid integer job ID.")
            continue

        job_id = int(inp)
        entry = TableEntry()
        entry.routine_id   = 'R2'
        entry.job_id       = job_id
        entry.table_number = 0   # ignored by people node
        entry.vacancy      = False
        pub.publish(entry)
        rospy.loginfo("Published R2 job %d to /table_bot/r2_entries", job_id)

    rospy.signal_shutdown("User exit")

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass

