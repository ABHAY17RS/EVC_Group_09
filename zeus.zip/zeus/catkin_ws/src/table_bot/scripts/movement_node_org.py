#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy
import time
import math
import Jetson.GPIO as GPIO
from table_bot.msg import TableEntry, GoSignal
from std_msgs.msg import Empty
from motorScripts.motorDriver import DaguWheelsDriver
from encoderScripts.encoderDriver import WheelEncoderDriver

class MovementNode(object):
    def __init__(self):
        # GPIO + ROS init
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BOARD)
        GPIO.cleanup()
        rospy.init_node('jetbot_movement_node', anonymous=True)

        # Publishers & Subscriber
        self.pub_qr   = rospy.Publisher('/table_bot/qr_trigger', Empty, queue_size=1)
        self.pub_done = rospy.Publisher('/table_bot/task_complete', GoSignal, queue_size=1)
        rospy.Subscriber('/table_bot/flow_entries', TableEntry, self.entry_callback)

        # Motor & encoder drivers
        self.drv  = DaguWheelsDriver()
        self.encL = WheelEncoderDriver(12)
        self.encR = WheelEncoderDriver(35)

        # Physical constants
        self.V_MAX         = 0.7       # max wheel speed (m/s)
        self.radius        = 0.03      # wheel radius (m)
        self.ticks_per_rev = 137       # encoder resolution
        self.trim          = -0.135    # speed trim
        self.wheel_base    = 0.23      # distance between wheels (m)
        self.speed         = 0.3       # default speed for test

        # Keep track of where we are
        self.current = 'home'

        # Hard-coded route steps: (action, value, speed)
        # turn: degrees, drive: meters
        # Right turn = -90°, Left = +90°
        self.routes = {
            ('home','table1'): [
                ('turn', -90, self.speed),
                ('drive', 0.50, self.speed),
                ('turn', +90, self.speed),
                ('drive', 1.00, self.speed),
            ],
            ('home','table2'): [
                ('turn', -90, self.speed),
                ('drive', 0.50, self.speed),
                ('turn', +90, self.speed),
                ('drive', 2.00, self.speed),
            ],
            ('home','table3'): [
                ('turn', +90, self.speed),
                ('drive', 0.50, self.speed),
                ('turn', -90, self.speed),
                ('drive', 1.00, self.speed),
            ],
            ('home','table4'): [
                ('turn', +90, self.speed),
                ('drive', 0.50, self.speed),
                ('turn', -90, self.speed),
                ('drive', 2.00, self.speed),
            ],
            ('home','kitchen'): [
                ('drive', 3.00, self.speed),
            ],
        }
        # Build the reverse routes automatically:
        for src, dst in list(self.routes.keys()):
            rev = []
            # to undo, reverse the list and negate turn, keep drive but reverse direction
            for act, val, sp in reversed(self.routes[(src,dst)]):
                if act == 'turn':
                    rev.append(('turn', -val, sp))
                elif act == 'drive':
                    rev.append(('drive', val, -sp))
            self.routes[(dst,src)] = rev

        rospy.loginfo("MovementNode ready; current loc = home.")

    def entry_callback(self, entry):
        # map table_number to name
        target = 'kitchen' if entry.table_number == 0 else 'table{}'.format(entry.table_number)
        rospy.loginfo("Job {}: {} -> {}".format(entry.job_id, self.current, target))

        # ensure route exists
        route = self.routes.get((self.current, target), None)
        if route is None:
            rospy.logerr("No hard-coded route: {} -> {}".format(self.current, target))
            return

        # execute each step
        for act, val, sp in route:
            if act == 'turn':
                rospy.loginfo("  turn({:+.0f}°)".format(val))
                self.turn(val, sp)
            else:  # drive
                rospy.loginfo("  drive_distance({:.2f}m)".format(val))
                self.drive_distance(val, sp)

        # arrived!
        if target == 'kitchen':
            rospy.loginfo("Arrived at kitchen → triggering QR scan")
            self.pub_qr.publish(Empty())
        else:
            rospy.loginfo("Arrived at {}; simulating 10s service".format(target))
            time.sleep(10)
            # now return home automatically
            rospy.loginfo("Returning home")
            for act, val, sp in self.routes[(target,'home')]:
                if act == 'turn':
                    self.turn(val, sp)
                else:
                    self.drive_distance(val, sp)
            target = 'home'
            rospy.loginfo("Back home; Job {} done".format(entry.job_id))
            self.pub_done.publish(GoSignal(job_id=entry.job_id))

        # update location
        self.current = target

    def turn(self, degrees, cmd):
        # reset encoders
        self.encL._ticks = self.encR._ticks = 0
        # compute needed ticks
        arc = math.radians(degrees) * (self.wheel_base/2.0)
        ticks = int(abs(arc)/(2*math.pi*self.radius)*self.ticks_per_rev)
        # set wheel directions
        if degrees >= 0:
            l, r = 1, -1
        else:
            l, r = -1, 1
        self.drv.set_wheels_speed(l*cmd*(1-self.trim), r*cmd*(1+self.trim))
        # wait
        while max(abs(self.encL._ticks), abs(self.encR._ticks)) < ticks and not rospy.is_shutdown():
            time.sleep(0.005)
        self.drv.set_wheels_speed(0,0)
        time.sleep(0.1)

    def drive_distance(self, dist_m, cmd):
        # reset encoders
        self.encL._ticks = self.encR._ticks = 0
        # target ticks
        ticks = int(abs(dist_m)/(2*math.pi*self.radius)*self.ticks_per_rev)
        # set speed (negative for reverse)
        self.drv.set_wheels_speed(cmd*(1-self.trim), cmd*(1+self.trim))
        # wait
        while (abs(self.encL._ticks)+abs(self.encR._ticks))/2.0 < ticks and not rospy.is_shutdown():
            time.sleep(0.005)
        self.drv.set_wheels_speed(0,0)
        time.sleep(0.1)

if __name__ == '__main__':
    MovementNode()
    rospy.spin()

