import time
from motorDriver import DaguWheelsDriver

DRIVE_SPEED = 0.3   # slower so you can observe drift
DT = 5            # run time
trim = -0.07

def test(trim):
    driver = DaguWheelsDriver()
    v_l = DRIVE_SPEED * (1 - trim)
    v_r = DRIVE_SPEED * (1 + trim)
    driver.set_wheels_speed(v_l * (1 - trim), v_r * (1 + trim))
    time.sleep(DT)
    driver.set_wheels_speed(0, 0)
    driver.close()
    # After it stops, measure lateral offset relative to start:
    inp = input("Trim="+str(trim)+" -> measured offset to the right (m): ")
    offset = float(inp)
    return offset

print("Iteratively adjust trim so offset = 0")
while True:
    offset = test(trim)
    if abs(offset) < 0.02:
        print("Good enough! Final trim = ", trim)
        break
    # If the bot drifted right, offset>0, steer left => increase trim
    # If it drifted left (offset<0), steer right => decrease trim
    trim += (offset / DT) * 0.1   # simple proportional step
    print("Next trim guess: ", trim)
