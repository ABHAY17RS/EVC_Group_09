#!/usr/bin/env python2

import curses
from motorScripts.motorDriver import *
from time import sleep
import yaml

def load_yaml(filename="./motorScripts/parameters.yaml"):
    with open(filename, "r") as f:
        return yaml.safe_load(f)


# Low speed value
config = load_yaml()
print(config)
trim = config.get('trim', 0)
gain = config.get('gain', 1)
velocity = 0.3
velocity_l = velocity * (1 - trim)  # Keep it in [-1, 1] range
velocity_r = velocity * (1 + trim)  # Keep it in [-1, 1] range

def main(stdscr):
    motor = DaguWheelsDriver()

    # Clear screen and disable cursor
    curses.curs_set(0)
    stdscr.nodelay(True)
    stdscr.clear()
    stdscr.addstr(0, 0, "Use arrow keys to move. Press 'q' to quit.")

    try:
        while True:
            key = stdscr.getch()

            if key == curses.KEY_UP:
                motor.set_wheels_speed(left=velocity_l, right=velocity_r)
            elif key == curses.KEY_DOWN:
                motor.set_wheels_speed(left=-velocity_l, right=-velocity_r)
            elif key == curses.KEY_LEFT:
                motor.set_wheels_speed(left=-velocity_l, right=velocity_r)
            elif key == curses.KEY_RIGHT:
                motor.set_wheels_speed(left=velocity_l, right=-velocity_r)
            elif key == ord('q'):
                break
            else:
                motor.set_wheels_speed(left=0, right=0)

            sleep(0.05) 
    except KeyboardInterrupt:
        pass
    finally:
        motor.set_wheels_speed(left=0, right=0)
        motor.close()
        curses.endwin()

if __name__ == '__main__':
    curses.wrapper(main)
