#!/usr/bin/env python3
import time
import statistics
from motorDriver import DaguWheelsDriver

SAMPLE_GAIN = 0.766
CMD_SPEED = 0.5
DT        = 2.0       
TRIALS    = 3         
TRIM      = -0.075


def single_trial(cmd_speed, dt):
    driver = DaguWheelsDriver()
    print(f"\nStarting trial: cmd_speed={cmd_speed:.2f},  duration={dt:.1f}s")
    t0 = time.time()
    driver.set_wheels_speed(cmd_speed * (1 - TRIM), cmd_speed * (1 + TRIM))
    time.sleep(dt)
    driver.set_wheels_speed(0, 0)
    driver.close()
    elapsed = time.time() - t0

    dist = float(input("→ Measure the straight-line distance travelled (meters) and enter here: "))
    meas_speed = dist / elapsed
    gain = meas_speed / cmd_speed
    print(f"   Measured speed = {meas_speed:.3f} m/s  →  gain = {gain:.3f}")
    return gain


def main():
    gains = []
    for i in range(TRIALS):
        g = single_trial(CMD_SPEED, DT)
        gains.append(g)
        if i < TRIALS - 1:
            input("\nPress Enter to place the robot back on the start line for the next trial…")

    g_final = statistics.mean(gains)
    print(f"Gain calibration complete:  g = {g_final:.3f}")


if __name__ == "__main__":
    main()
