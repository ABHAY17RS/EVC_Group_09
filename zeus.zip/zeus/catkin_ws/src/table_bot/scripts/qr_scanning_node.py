#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy
import cv2
from cv_bridge import CvBridge
from std_msgs.msg import Empty
from jetson_camera.msg import RawAndUndistorted
from table_bot.msg import TableEntry

class QRCodeNode(object):
    def __init__(self):
        rospy.init_node('qr_scanning_node', anonymous=False)

        # bridge & detector
        self.bridge     = CvBridge()
        self.detector   = cv2.QRCodeDetector()

        # publisher for decoded entries
        self.pub_flow   = rospy.Publisher(
            '/table_bot/flow_entries', TableEntry, queue_size=1)

        # internal state
        self.current_entry = None
        self.triggered     = False

        # subscriptions
        rospy.Subscriber(
            '/table_bot/r2_entries', TableEntry, self.entry_cb)
        rospy.Subscriber(
            '/table_bot/qr_trigger', Empty, self.trigger_cb)
        rospy.Subscriber(
            '/camera/raw_and_undistorted', RawAndUndistorted,
            self.image_cb, queue_size=1, buff_size=2**24)

        rospy.loginfo("QR scanning node started.")
        rospy.spin()

    def entry_cb(self, entry):
        # cache only R1 jobs that expect a QR at the kitchen
        if entry.routine_id != 'R2':
            return
        self.current_entry = entry
        rospy.loginfo("QR node: cached entry for job %d", entry.job_id)

    def trigger_cb(self, _msg):
        # Received go‐ahead from movement node
        if self.current_entry is not None:
            self.triggered = True
            rospy.loginfo("QR node: trigger received for job %d",
                          self.current_entry.job_id)

    def image_cb(self, msg):
        # only attempt decode if triggered
        if not self.triggered or self.current_entry is None:
            return

        # convert ROS Image → OpenCV
        try:
            img = self.bridge.imgmsg_to_cv2(
                msg.undistorted_image, desired_encoding='bgr8')
        except Exception as e:
            rospy.logerr("QR node: CvBridge error: %s", str(e))
            return

        # detect & decode
        data_str, pts, _ = self.detector.detectAndDecode(img)
        if not data_str or pts is None:
            return

        data_str = data_str.strip()
        # parse integer table number
        try:
            table_num = int(data_str)
        except ValueError:
            rospy.logwarn("QR node: cannot parse '%s' as table number", data_str)
            return

        # publish the decoded entry
        out = TableEntry()
        out.routine_id   = self.current_entry.routine_id
        out.job_id       = self.current_entry.job_id
        out.table_number = table_num
        out.vacancy      = False

        self.pub_flow.publish(out)
        rospy.loginfo("QR node: published TableEntry(job=%d → table%d)",
                      out.job_id, table_num)

        # reset for next job
        self.current_entry = None
        self.triggered     = False

if __name__ == '__main__':
    try:
        QRCodeNode()
    except rospy.ROSInterruptException:
        pass


