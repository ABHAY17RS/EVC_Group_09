#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy, time
import cv2
import numpy as np
from cv_bridge import CvBridge, CvBridgeError
from jetson_camera.msg import RawAndUndistorted
from table_bot.msg import TableEntry

class PeopleDetectionNode(object):
    def __init__(self):
        rospy.init_node('people_detection_node', anonymous=False)
        self.bridge = CvBridge()

        # State flags
        self.active_job      = None
        self.detecting       = False    # looking for motion+face
        self.counting        = False    # 5s people‐count window
        self.count_start_t   = 0.0
        self.counts          = []

        # Motion‐/face‐detector setup
        self.bg              = None
        self.accum_weight    = 0.5
        self.min_area        = 500
        self.motion_thresh   = 25
        self.motion_kernel   = cv2.getStructuringElement(
                                cv2.MORPH_ELLIPSE, (5,5))
        self.frame_skip      = 1
        self.frame_count     = 0

        # Haar for face trigger
        haar_path = "/home/jetbot/models/haarcascade_frontalface_default.xml"
        self.face_cascade = cv2.CascadeClassifier()
        if not self.face_cascade.load(haar_path):
            rospy.logerr("Cannot load Haar cascade: %s", haar_path)
            raise IOError("Failed to load face model")

        # MobileNet-SSD for person counting
        model_dir = "/home/jetbot/models/people_counter/"
        proto     = model_dir + "MobileNetSSD_deploy.prototxt"
        model     = model_dir + "MobileNetSSD_deploy.caffemodel"
        self.net = cv2.dnn.readNetFromCaffe(proto, model)
        self.PERSON_CLASS_ID = 15  # SSD “person” index

        # Publishers & subscribers
        self.pub_flow = rospy.Publisher(
            '/table_bot/flow_entries', TableEntry, queue_size=1)
        rospy.Subscriber(
            '/table_bot/r1_entries', TableEntry, self.r1_callback, queue_size=1)
        rospy.Subscriber(
            '/camera/raw_and_undistorted', RawAndUndistorted,
            self.camera_callback, buff_size=2**24, queue_size=1)

        rospy.loginfo("PeopleDetectionNode ready.")
        rospy.spin()

    def r1_callback(self, entry):
        if entry.routine_id != 'R1':      # only handle R1 here
            return
        if not self.active_job:
            self.active_job    = entry
            self.detecting     = True
            self.bg            = None
            self.frame_count   = 0
            rospy.loginfo("R1 job %d: start motion+face scan", entry.job_id)
        else:
            rospy.logwarn("Busy with job %d; ignoring %d",
                          self.active_job.job_id, entry.job_id)

    def camera_callback(self, msg):
        if not (self.detecting or self.counting):
            return

        # Decode image
        try:
            img = self.bridge.imgmsg_to_cv2(
                msg.undistorted_image, desired_encoding='bgr8')
        except CvBridgeError as e:
            rospy.logerr("CvBridge err: %s", e)
            return

        self.frame_count += 1
        if self.frame_count % self.frame_skip:
            return

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (7,7), 0)

        # Init background
        if self.bg is None:
            self.bg = gray.astype("float")
            return

        # Motion detection
        cv2.accumulateWeighted(gray, self.bg, self.accum_weight)
        delta  = cv2.absdiff(gray, cv2.convertScaleAbs(self.bg))
        thresh = cv2.threshold(
            delta, self.motion_thresh, 255, cv2.THRESH_BINARY)[1]
        thresh = cv2.morphologyEx(
            thresh, cv2.MORPH_CLOSE, self.motion_kernel)
        cnts, _ = cv2.findContours(
            thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        motion = any(cv2.contourArea(c) >= self.min_area for c in cnts)
        if not motion and not self.counting:
            return

        # Face‐trigger phase
        if self.detecting and motion:
            faces = self.face_cascade.detectMultiScale(
                gray, scaleFactor=1.1, minNeighbors=5, minSize=(30,30))
            if len(faces) > 0:
                rospy.loginfo("Face detected → start 5s people count")
                self.detecting   = False
                self.counting    = True
                self.count_start_t = time.time()
                self.counts      = []
            else:
                return

        # Counting phase (5 seconds)
        if self.counting:
            # Run MobileNet-SSD blob
            blob = cv2.dnn.blobFromImage(
                cv2.resize(img, (300,300)), 0.007843, (300,300), 127.5)
            self.net.setInput(blob)
            detections = self.net.forward()
            person_count = 0
            h, w = img.shape[:2]
            for i in range(detections.shape[2]):
                conf = detections[0,0,i,2]
                cls  = int(detections[0,0,i,1])
                if conf>0.4 and cls==self.PERSON_CLASS_ID:
                    person_count += 1
            self.counts.append(person_count)

            # Check 5s timer
            elapsed = time.time() - self.count_start_t
            if elapsed >= 5.0:
                final_count = max(self.counts) if self.counts else 0
                rospy.loginfo("5s done; max people = %d", final_count)

                # Table assignment
                if   final_count<=1: table_num=1
                elif final_count==2: table_num=2
                elif final_count==3: table_num=3
                else:                table_num=4

                # Publish to movement pipeline
                out = TableEntry()
                out.routine_id   = 'R1'
                out.job_id       = self.active_job.job_id
                out.table_number = table_num
                out.vacancy      = False
                self.pub_flow.publish(out)
                rospy.loginfo("Published TableEntry(job=%d → table%d)",
                              out.job_id, table_num)

                # Reset state
                self.active_job = None
                self.counting  = False

if __name__ == '__main__':
    try:
        PeopleDetectionNode()
    except rospy.ROSInterruptException:
        pass


