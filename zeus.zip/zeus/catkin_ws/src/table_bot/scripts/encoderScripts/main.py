from time import sleep
from encoderScripts.encoderDriver import WheelEncoderDriver
from motorScripts.motorDriver   import DaguWheelsDriver

GPIO_MOTOR_ENCODER_1=12
GPIO_MOTOR_ENCODER_2=35

driver_1 = WheelEncoderDriver(GPIO_MOTOR_ENCODER_1)
driver_2 = WheelEncoderDriver(GPIO_MOTOR_ENCODER_2)


while True:
    print("Motor Encoder 1: {} \t Motor Encoder 2: {}".format(driver_1._ticks, driver_2._ticks))
    sleep(1)
