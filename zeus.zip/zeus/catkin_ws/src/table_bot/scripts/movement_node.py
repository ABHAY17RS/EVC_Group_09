#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy, time, math
import Jetson.GPIO as GPIO
from table_bot.msg import TableEntry, GoSignal
from std_msgs.msg import Empty
from motorScripts.motorDriver import DaguWheelsDriver
from encoderScripts.encoderDriver import WheelEncoderDriver

# ─── PID CONTROLLER ─────────────────────────────────────────────────────────────

class PIDController(object):
    def __init__(self, kp, ki, kd, output_limits=(None, None)):
        self.kp, self.ki, self.kd = kp, ki, kd
        self.min_out, self.max_out = output_limits
        self._last_error = 0.0
        self._integral   = 0.0
        self._last_time  = None

    def reset(self):
        self._last_error = 0.0
        self._integral   = 0.0
        self._last_time  = None

    def update(self, error):
        now = time.time()
        dt  = 0.0 if self._last_time is None else (now - self._last_time)
        self._last_time = now

        # integrate
        self._integral += error * dt
        # derivative
        deriv = 0.0 if dt == 0.0 else (error - self._last_error)/dt
        self._last_error = error

        # PID output
        out = (self.kp*error) + (self.ki*self._integral) + (self.kd*deriv)
        if self.max_out is not None: out = min(self.max_out, out)
        if self.min_out is not None: out = max(self.min_out, out)
        return out

# ─── MOVEMENT NODE ────────────────────────────────────────────────────────────────

class MovementNode(object):
    def __init__(self):
        # GPIO + ROS init
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BOARD)
        GPIO.cleanup()
        rospy.init_node('jetbot_movement_node', anonymous=True)

        # Publishers & Subscriber
        self.pub_qr   = rospy.Publisher('/table_bot/qr_trigger', Empty, queue_size=1)
        self.pub_done = rospy.Publisher('/table_bot/task_complete', GoSignal, queue_size=1)
        rospy.Subscriber('/table_bot/flow_entries', TableEntry, self.entry_callback)

        # Motor & encoder drivers
        self.drv  = DaguWheelsDriver()
        self.encL = WheelEncoderDriver(12)
        self.encR = WheelEncoderDriver(35)

        # Physical constants
        self.V_MAX         = 0.7
        self.radius        = 0.03
        self.ticks_per_rev = 137
        self.trim          = -0.135
        self.wheel_base    = 0.23

        # PID for wheel‐slip correction (tweak these gains)
        self.pid = PIDController(
            kp=0.8,    # bigger: stronger correction
            ki=0.02,   # small: compensate steady‐state drift
            kd=0.01,   # small: damp oscillations
            output_limits=(-0.3, 0.3)
        )

        # default straight‐line speed
        self.speed = 0.3

        # keep current location
        self.current = 'home'

        # hard-coded routes (unchanged)
        self.routes = {
            ('home','table1'): [('turn',-90),('drive',0.50),('turn',+90),('drive',1.00)],
            ('home','table2'): [('turn',-90),('drive',0.50),('turn',+90),('drive',2.00)],
            ('home','table3'): [('turn',+90),('drive',0.50),('turn',-90),('drive',1.00)],
            ('home','table4'): [('turn',+90),('drive',0.50),('turn',-90),('drive',2.00)],
            ('home','kitchen'): [('drive',3.00)],
        }
        for src,dst in list(self.routes):
            rev = []
            for act,val in reversed(self.routes[(src,dst)]):
                if act=='turn':  rev.append(('turn', -val))
                else:            rev.append(('drive', val))
            self.routes[(dst,src)] = rev

        rospy.loginfo("MovementNode ready; current loc = home.")

    def entry_callback(self, entry):
        target = 'kitchen' if entry.table_number==0 else 'table%d'%entry.table_number
        rospy.loginfo("Job %d: %s -> %s", entry.job_id, self.current, target)
        route = self.routes.get((self.current,target))
        if not route:
            rospy.logerr("No route: %s->%s", self.current, target)
            return

        # execute
        for act,val in route:
            if act=='turn':
                rospy.loginfo(" turn(%+d°)"%val)
                self.turn(val)
            else:
                rospy.loginfo(" drive(%.2fm)"%val)
                self.drive_distance(val)

        # post‐arrival
        if target=='kitchen':
            rospy.loginfo("Arrived at kitchen → QR")
            self.pub_qr.publish(Empty())
        else:
            rospy.loginfo("Arrived at %s → wait 10s", target)
            time.sleep(10)
            rospy.loginfo("Returning home")
            for act,val in self.routes[(target,'home')]:
                if act=='turn': self.turn(val)
                else:           self.drive_distance(val)
            rospy.loginfo("Job %d done", entry.job_id)
            self.pub_done.publish(GoSignal(job_id=entry.job_id))

        self.current = target

    def turn(self, degrees):
        # unchanged
        self.encL._ticks = self.encR._ticks = 0
        arc = math.radians(degrees)*(self.wheel_base/2.0)
        t_target = int(abs(arc)/(2*math.pi*self.radius)*self.ticks_per_rev)
        ldir,rdir = (1,-1) if degrees>=0 else (-1,1)
        self.drv.set_wheels_speed(ldir*self.speed*(1-self.trim),
                                  rdir*self.speed*(1+self.trim))
        while max(abs(self.encL._ticks),abs(self.encR._ticks))<t_target and not rospy.is_shutdown():
            time.sleep(0.005)
        self.drv.set_wheels_speed(0,0)
        time.sleep(0.1)

    def drive_distance(self, dist_m):
        # encoder & PID reset
        self.encL._ticks = self.encR._ticks = 0
        self.pid.reset()

        ticks_target = int(abs(dist_m)/(2*math.pi*self.radius)*self.ticks_per_rev)

        # loop until average ticks reached
        while not rospy.is_shutdown():
            tL = abs(self.encL._ticks)
            tR = abs(self.encR._ticks)
            avg = (tL + tR)/2.0
            if avg >= ticks_target:
                break

            # slip error → positive if left wheel ahead
            error = (tL - tR)/float(self.ticks_per_rev)
            corr  = self.pid.update(error)

            v_left  = max(min(self.speed - corr, self.V_MAX), -self.V_MAX)
            v_right = max(min(self.speed + corr, self.V_MAX), -self.V_MAX)

            self.drv.set_wheels_speed(
                v_left*(1-self.trim),
                v_right*(1+self.trim)
            )
            time.sleep(0.005)

        # stop
        self.drv.set_wheels_speed(0,0)
        time.sleep(0.1)

if __name__=='__main__':
    MovementNode()
    rospy.spin()

