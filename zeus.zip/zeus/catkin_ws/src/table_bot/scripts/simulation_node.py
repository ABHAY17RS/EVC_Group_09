#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy
import threading
from table_bot.msg import TableEntry, GoSignal

class SimulationNode(object):
    """
    NODE5: Simulates restaurant: handles seating (entrance) and order-ready (kitchen).
    - Listens for completion of each job on /table_bot/next_task
    - Reads console input: 'entrance' or 'kitchen'
    - Manages 4 tables (et1..et4) empty=True/vacant, False=occupied
    - Publishes TableEntry to /table_bot/table_entries
    """
    def __init__(self):
        rospy.init_node('simulation_node')
        self.pub_entries = rospy.Publisher(
            '/table_bot/table_entries', TableEntry, queue_size=10)
        rospy.Subscriber(
            '/table_bot/next_task', GoSignal, self.on_task_complete)

        self.table_states = [True] * 4  # True = empty/vacant
        self.job_counter = 0
        self.waiting_for_completion = False

        # Start console input thread
        thread = threading.Thread(target=self.console_loop)
        thread.daemon = True
        thread.start()

        rospy.loginfo("Simulation node started. Type 'entrance' or 'kitchen' and press Enter.")
        rospy.spin()

    def console_loop(self):
        while not rospy.is_shutdown():
            cmd = raw_input().strip().lower()
            if cmd not in ('entrance', 'kitchen'):
                print("Unknown command. Please type 'entrance' or 'kitchen'.")
                continue

            if self.waiting_for_completion:
                print("Waiting for previous job to complete. Please wait...")
                continue

            self.job_counter += 1
            entry = TableEntry()
            entry.job_id = self.job_counter

            if cmd == 'entrance':
                entry.routine_id = 'R1'
                # check for an empty table
                vacant_idx = None
                for idx, empty in enumerate(self.table_states):
                    if empty:
                        vacant_idx = idx
                        break
                if vacant_idx is not None:
                    entry.vacancy      = True
                    entry.table_number = vacant_idx + 1    # <— assign actual table #
                    # reserve it (final table assignment via QR scanning)
                    self.table_states[vacant_idx] = False
                    print("Seating party at table%d" % (vacant_idx+1))
                else:
                    entry.vacancy      = False
                    entry.table_number = 0                  # no table to seat
                    print("No vacant tables available.")

            else:  # 'kitchen'
                entry.routine_id = 'R2'
                # check for occupied table
                occ_idx = None
                for idx, empty in enumerate(self.table_states):
                    if not empty:
                        occ_idx = idx
                        break
                if occ_idx is not None:
                    entry.table_number = occ_idx + 1
                    entry.vacancy      = False
                    print("Order ready for table%d" % (occ_idx+1))
                else:
                    entry.table_number = 0
                    entry.vacancy      = True
                    print("No occupied tables to serve.")

            # publish and wait for completion callback
            self.pub_entries.publish(entry)
            rospy.loginfo("Published %s job %d", entry.routine_id, entry.job_id)
            self.waiting_for_completion = True

    def on_task_complete(self, msg):
        # Received GoSignal from movement_node upon completion
        if msg.job_id <= 0:
            return
        rospy.loginfo("Job %d complete; ready for next command.", msg.job_id)
        self.waiting_for_completion = False

if __name__ == '__main__':
    try:
        SimulationNode()
    except rospy.ROSInterruptException:
        pass

