#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy
import time
from table_bot.msg import TableEntry
from std_msgs.msg import Empty

def main():
    rospy.init_node('test_pub_qr', anonymous=True)
    pub_entry = rospy.Publisher('/table_bot/flow_entries', TableEntry, queue_size=1)
    pub_trigger = rospy.Publisher('/table_bot/qr_trigger', Empty, queue_size=1)

    # wait for subscribers to connect
    rospy.sleep(1.0)

    print("▶ Publishing R1 entry (table_number=0) for job_id=1 …")
    entry = TableEntry()
    entry.routine_id   = 'R1'
    entry.job_id       = 1
    entry.table_number = 0
    entry.vacancy      = True
    pub_entry.publish(entry)

    # give the QR node a moment to cache it
    time.sleep(0.5)

    print("▶ Publishing trigger (Empty) on /table_bot/qr_trigger")
    pub_trigger.publish(Empty())

    print("✅ Done. QR node should decode next camera frame and re-publish a new TableEntry.")

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass

