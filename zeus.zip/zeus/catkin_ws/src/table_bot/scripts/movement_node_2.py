#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import rospy
import time
import math
import Jetson.GPIO as GPIO
from table_bot.msg import TableEntry, GoSignal
from std_msgs.msg import Empty
from motorScripts.motorDriver import DaguWheelsDriver
from encoderScripts.encoderDriver import WheelEncoderDriver
from tofScripts.tofDriver import VL53L0X

class PIDController(object):
    def __init__(self, kp, ki, kd, output_limits=(None, None)):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.min_out, self.max_out = output_limits
        self._last_error = 0.0
        self._integral = 0.0
        self._last_time = None

    def reset(self):
        self._last_error = 0.0
        self._integral = 0.0
        self._last_time = None

    def update(self, error):
        now = time.time()
        dt = 0.0 if self._last_time is None else (now - self._last_time)
        self._last_time = now
        self._integral += error * dt
        derivative = 0.0 if dt == 0.0 else (error - self._last_error) / dt
        self._last_error = error
        output = (self.kp * error) + (self.ki * self._integral) + (self.kd * derivative)
        if self.max_out is not None:
            output = min(self.max_out, output)
        if self.min_out is not None:
            output = max(self.min_out, output)
        return output

class MovementNode(object):
    def __init__(self):
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BOARD)
        GPIO.cleanup()
        rospy.init_node('jetbot_movement_node', anonymous=True)

        self.pub_qr = rospy.Publisher('/table_bot/qr_trigger', Empty, queue_size=1)
        self.pub_done = rospy.Publisher('/table_bot/task_complete', GoSignal, queue_size=1)
        rospy.Subscriber('/table_bot/flow_entries', TableEntry, self.entry_callback)

        self.drv = DaguWheelsDriver()
        self.encL = WheelEncoderDriver(12)
        self.encR = WheelEncoderDriver(35)

        self.V_MAX = 0.7
        self.radius = 0.03
        self.ticks_per_rev = 137
        self.trim = -0.135
        self.wheel_base = 0.23

        self.pid = PIDController(kp=0.5, ki=0.0, kd=0.1, output_limits=(-0.3, 0.3))

        self.locations = {
            'home': (0, 0),
            'table1': (50, 100),
            'table2': (50, 200),
            'table3': (-50, 100),
            'table4': (-50, 200),
            'kitchen': (0, 300)
        }

        self.current_pos = (0, 0)
        self.current_name = 'home'

        self.tof = VL53L0X()
        self.tof.start_ranging(VL53L0X.VL53L0X_GOOD_ACCURACY_MODE)
        self.obstacle_mm = 400
        rospy.on_shutdown(self._shutdown_tof)

        rospy.loginfo('MovementNode initialized and waiting for jobs...')

    def _shutdown_tof(self):
        try:
            self.tof.stop_ranging()
        except:
            pass
        self.drv.set_wheels_speed(0, 0)

    def _is_obstacle(self):
        try:
            d = self.tof.get_distance()
            return d > 0 and d < self.obstacle_mm
        except:
            return False

    def _avoid_obstacle(self, cmd):
        rospy.loginfo('Obstacle detected – executing detour.')
        self.drive_distance(0.10, -cmd)
        self.turn(90, cmd)
        self.drive_distance(0.30, cmd)
        self.turn(-90, cmd)
        self.drive_distance(0.50, cmd)
        self.turn(-90, cmd)
        self.drive_distance(0.30, cmd)
        self.turn(90, cmd)
        rospy.loginfo('Detour complete.')

    def entry_callback(self, entry):
        if entry.table_number == 0:
            target_name = 'kitchen'
        else:
            target_name = 'table{}'.format(entry.table_number)
        rospy.loginfo('Job {}: Moving from {} to {}'.format(
            entry.job_id, self.current_name, target_name))
        self.go_to(target_name)
        if target_name == 'kitchen':
            rospy.loginfo('Arrived at kitchen, triggering QR scan')
            self.pub_qr.publish(Empty())
            self.current_name = 'kitchen'
            return
        rospy.loginfo('Arrived at {}, waiting 10s to simulate service'.format(target_name))
        time.sleep(10)
        rospy.loginfo('Returning home')
        self.go_to('home')
        self.current_name = 'home'
        rospy.loginfo('Job {} completed, publishing done'.format(entry.job_id))
        self.pub_done.publish(GoSignal(job_id=entry.job_id))

    def go_to(self, target_name):
        start, goal = self.current_pos, self.locations[target_name]
        dx, dy = goal[0] - start[0], goal[1] - start[1]
        distance = math.hypot(dx, dy) / 100.0
        desired_angle = math.degrees(math.atan2(dy, dx))
        angle_error = (desired_angle - self.get_heading() + 180) % 360 - 180
        if angle_error >= 0:
            turn_angle = angle_error
        else:
            turn_angle = 360 + angle_error
        rospy.loginfo('Rotating {:.1f}° via turn({:.1f})'.format(angle_error, turn_angle))
        self.turn(turn_angle, cmd=0.3)
        rospy.loginfo('Driving straight for {:.2f} m'.format(distance))
        self.drive_distance(distance, cmd=0.3)
        self.current_pos = goal

    def get_heading(self):
        if not hasattr(self, '_heading'):
            self._heading = 0.0
        return self._heading

    def turn(self, degrees, cmd):
        self.encL._ticks = self.encR._ticks = 0
        arc = math.radians(degrees) * (self.wheel_base / 2.0)
        ticks_target = int(abs(arc) / (2 * math.pi * self.radius) * self.ticks_per_rev)
        if degrees >= 0:
            ldir, rdir = 1, -1
        else:
            ldir, rdir = -1, 1
        v = cmd
        self.drv.set_wheels_speed(
            ldir * v * (1 - self.trim), rdir * v * (1 + self.trim)
        )
        while max(abs(self.encL._ticks), abs(self.encR._ticks)) < ticks_target and not rospy.is_shutdown():
            time.sleep(0.005)
        self.drv.set_wheels_speed(0, 0)
        time.sleep(0.2)
        self._heading = (self.get_heading() + degrees) % 360

    def drive_distance(self, distance_m, cmd):
        self.encL._ticks = self.encR._ticks = 0
        self.pid.reset()
        ticks_target = int(distance_m / (2 * math.pi * self.radius) * self.ticks_per_rev)
        v_cmd = cmd
        while not rospy.is_shutdown():
            if cmd > 0 and self._is_obstacle():
                prog = (abs(self.encL._ticks) + abs(self.encR._ticks)) / 2.0
                prog_m = prog / self.ticks_per_rev * 2 * math.pi * self.radius
                remaining = max(0.0, distance_m - prog_m)
                self.drv.set_wheels_speed(0, 0)
                self._avoid_obstacle(abs(cmd))
                if remaining < 0.01:
                    break
                self.encL._ticks = self.encR._ticks = 0
                ticks_target = int(remaining / (2 * math.pi * self.radius) * self.ticks_per_rev)
            tL, tR = abs(self.encL._ticks), abs(self.encR._ticks)
            if (tL + tR) / 2.0 >= ticks_target:
                break
            error = (tL - tR) / float(self.ticks_per_rev)
            corr = self.pid.update(error)
            v_left = max(min(v_cmd - corr, self.V_MAX), -self.V_MAX)
            v_right = max(min(v_cmd + corr, self.V_MAX), -self.V_MAX)
            self.drv.set_wheels_speed(
                v_left * (1 - self.trim), v_right * (1 + self.trim)
            )
            time.sleep(0.005)
        self.drv.set_wheels_speed(0, 0)
        time.sleep(0.2)

if __name__ == '__main__':
    try:
        node = MovementNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass

