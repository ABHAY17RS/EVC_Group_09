#!/usr/bin/env python2
# -*- coding: utf-8 -*-
 
import rospy, time, math
import Jetson.GPIO as GPIO
from std_msgs.msg import Empty
from table_bot.msg import TableEntry, GoSignal
from motorScripts.motorDriver import DaguWheelsDriver
from encoderScripts.encoderDriver import WheelEncoderDriver
 
class PIDController(object):
    def __init__(self, kp, ki, kd, out_min=None, out_max=None):
        self.kp, self.ki, self.kd = kp, ki, kd
        self.min, self.max = out_min, out_max
        self._int = 0.0
        self._prev = 0.0
        self._t0 = None
    def reset(self):
        self._int = 0.0
        self._prev = 0.0
        self._t0 = None
    def update(self, err):
        t = time.time()
        dt = (t - self._t0) if self._t0 else 0.0
        self._t0 = t
        self._int += err*dt
        deriv = (err - self._prev)/dt if dt>0 else 0.0
        self._prev = err
        out = self.kp*err + self.ki*self._int + self.kd*deriv
        if self.max is not None: out = min(self.max, out)
        if self.min is not None: out = max(self.min, out)
        return out
 
class MovementNode(object):
    def __init__(self):
        # GPIO + ROS init
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BOARD)
        GPIO.cleanup()
        rospy.init_node('jetbot_movement_node', anonymous=True)
 
        # Publishers & Subscriber
        self.pub_qr   = rospy.Publisher('/table_bot/qr_trigger', Empty,   queue_size=1)
        self.pub_done = rospy.Publisher('/table_bot/task_complete', GoSignal, queue_size=1)
        rospy.Subscriber('/table_bot/flow_entries', TableEntry, self.entry_callback)
        rospy.Subscriber('/table_bot/r2_entries', TableEntry, self.entry_callback)
        
        # Hardware drivers
        self.drv  = DaguWheelsDriver()
        self.encL = WheelEncoderDriver(12)
        self.encR = WheelEncoderDriver(35)
 
        # Physical constants
        self.V_MAX         = 0.7       # max wheel speed (m/s)
        self.radius        = 0.0325    # wheel radius (m)
        self.ticks_per_rev = 137       # encoder resolution
        self.trim          = -0.135    # wheel trim
        self.wheel_base    = 0.26      # baseline between wheels (m)
        self.speed         = 0.6       # default linear speed (m/s)
 
        # PID for straight‐drive correction
        self.drive_pid = PIDController(kp=0.5, ki=0.5, kd=0, out_min=-0.3, out_max=0.3)
 
        # State
        self.current = 'home'
        rospy.loginfo("MovementNode ready; current = home.")
 
        # Hard-coded routes (UTURN=180°, SRIGHT=+90°, SLEFT=–90°, DRIVE in meters)
        self.routes = {
            ('home','table1'): [
                ('turn',180), ('turn', 90),  ('drive',0.50),
                ('turn',-90),               ('drive',1.00),
            ],
            ('table1','home'): [
                ('turn',180), ('drive',1.00),
                ('turn', 90), ('drive',0.50),
                ('turn',-90),
            ],
            ('home','table2'): [
                ('turn',180), ('turn', 90),  ('drive',0.50),
                ('turn',-90),               ('drive',2.00),
            ],
            ('table2','home'): [
                ('turn',180), ('drive',2.00),
                ('turn', 90), ('drive',0.50),
                ('turn',-90),
            ],
            ('home','table3'): [
                ('turn',180), ('turn',-90), ('drive',0.50),
                ('turn', 90),               ('drive',1.00),
            ],
            ('table3','home'): [
                ('turn',180), ('drive',1.00),
                ('turn',-90), ('drive',0.50),
                ('turn', 90),
            ],
            ('home','table4'): [
                ('turn',180), ('turn',-90), ('drive',0.50),
                ('turn', 90),               ('drive',2.00),
            ],
            ('table4','home'): [
                ('turn',180), ('drive',2.00),
                ('turn',-90), ('drive',0.50),
                ('turn', 90),
            ],
            ('home','kitchen'): [
                ('turn',180), ('drive',3.00),
            ],
            ('kitchen','home'): [
                ('turn',180), ('drive',3.00),
            ],
            ('kitchen','table1'): [
                ('turn',180), ('turn',-90), ('drive',0.50),
                ('turn', 90),               ('drive',2.00),
                ('turn',180),
            ],
            ('kitchen','table2'): [
                ('turn',180), ('turn',-90), ('drive',0.50),
                ('turn', 90),               ('drive',1.00),
                ('turn',180),
            ],
            ('kitchen','table3'): [
                ('turn',180), ('turn', 90), ('drive',0.50),
                ('turn',-90),               ('drive',2.00),
                ('turn',180),
            ],
            ('kitchen','table4'): [
                ('turn',180), ('turn', 90), ('drive',0.50),
                ('turn',-90),               ('drive',1.00),
                ('turn',180),
            ],
        }
 
    def entry_callback(self, entry):
        if entry.routine_id == 'R1' and entry.table_number == 5:
            rospy.loginfo("Received R1 job %d → staying at home", entry.job_id)
            return
        #if entry.routine_id == 'R1' and entry.table_number != 5:
            #dst = 'table%d' % entry.table_number
            #self._execute_leg(self.current, dst)

        #For R2, visit kitchen first
        if entry.routine_id == 'R2' and self.current != 'kitchen':
            self._execute_leg(self.current, 'kitchen')
            self.current = 'kitchen'
 
        # Then requested leg
        dst = 'kitchen' if entry.table_number == 0 else 'table%d' % entry.table_number
        self._execute_leg(self.current, dst)
 
        if dst == 'kitchen':
            rospy.loginfo("Arrived at kitchen → QR trigger")
            self.pub_qr.publish(Empty())
            self.current = 'kitchen'
        else:
            rospy.loginfo("Arrived at %s → service (10s)", dst)
            time.sleep(10)
            self._execute_leg(dst, 'home')
            self.current = 'home'
            rospy.loginfo("Job %d done → back home", entry.job_id)
            self.pub_done.publish(GoSignal(job_id=entry.job_id))
 
    def _execute_leg(self, src, dst):
        route = self.routes.get((src, dst))
        if not route:
            rospy.logerr("No route defined: %s → %s", src, dst)
            return
        for act, val in route:
            if act == 'turn':
                rospy.loginfo(" turn(%+d°)", val)
                result = val + (val // 90) * 2 if val != -90 else val + (val // 90)*4
                self.turn(self.speed, self.radius, self.ticks_per_rev, result, self.wheel_base)
            else:
                rospy.loginfo(" drive(%.2fm)", val)
                # now uses PID-corrected straight drive
                self.drive_distance(val)
            time.sleep(2)  # 2-second pause between each command
 
    def turn(self, cmd, radius, ticks_per_rev, degrees, baseline):
        try:
            encL = self.encL
            encR = self.encR
            drv  = self.drv
            left = degrees < 0
            degrees = abs(degrees)
            degrees = [90] * (degrees // 90) + [degrees % 90]
            if degrees[-1] == 0:
                degrees.pop()
            for i, degree in enumerate(degrees):
                encL._ticks, encR._ticks = 0, 0
                distance = (math.pi * baseline) * (abs(degree) / 360.0)
                ticks_target = abs(int(distance / (2 * math.pi * radius) * ticks_per_rev))
 
                v = cmd
                l, r = 0, 0
                if left:
                    l = 1
                else:
                    r = 1
                drv.set_wheels_speed(v * l, v * r)
 
                while max(encL._ticks, encR._ticks) <= ticks_target:
                    time.sleep(0.005)
                drv.set_wheels_speed(0, 0)
 
                if i != len(degrees) - 1:
                    time.sleep(1)
        finally:
            self.drv.set_wheels_speed(0, 0)
 
    def drive_distance(self, dist_m):
        """
        PID‐corrected straight drive.
        """
        self.encL._ticks = self.encR._ticks = 0
        self.drive_pid.reset()
 
        target = int(dist_m / (2 * math.pi * self.radius) * self.ticks_per_rev)
        while True:
            L, R = self.encL._ticks, self.encR._ticks
            if (abs(L) + abs(R)) / 2.0 >= target:
                break
            err = L - R
            corr = self.drive_pid.update(err)
            vL = self.speed/1.25 - corr
            vR = self.speed/1.25 + corr
            # clip
            vL = max(min(vL, self.V_MAX), -self.V_MAX)
            vR = max(min(vR, self.V_MAX), -self.V_MAX)
            self.drv.set_wheels_speed(vL * (1 - self.trim),
                                      vR * (1 + self.trim))
            time.sleep(0.01)
 
        ramp_steps = 5
        for i in range(ramp_steps, -1, -1):
            frac = float(i) / ramp_steps
            self.drv.set_wheels_speed(self.speed * frac * (1 - self.trim),
                                      self.speed * frac * (1 + self.trim))
            time.sleep(0.02)
 
        # ensure full stop
        self.drv.set_wheels_speed(0, 0)
if __name__ == '__main__':
    MovementNode()
    rospy.spin()
