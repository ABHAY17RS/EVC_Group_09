#!/usr/bin/env python
import rospy
import cv2
import numpy as np
from sensor_msgs.msg import CompressedImage, Image
from cv_bridge import CvBridge
from jetson_camera.msg import RawAndUndistorted  # Update if your package name differs

class UndistortNode:
    def __init__(self):
        rospy.init_node(
            'image_undistort_node',
            anonymous=False
        )

        # Load camera calibration data from Jetson board path
        data = np.load('/home/jetbot/EVC/workshops/abhay2_w2_g9/calibration_data.npz')
        self.camera_matrix = data['camera_matrix']
        self.dist_coeffs = data['dist_coeffs']

        self.bridge = CvBridge()

        # Subscribe to compressed image topic from camera publisher
        rospy.Subscriber('/camera/image_raw', CompressedImage, self.callback, queue_size=1)

        # Publisher for custom message with both raw and undistorted images
        self.pub = rospy.Publisher('/camera/raw_and_undistorted', RawAndUndistorted, queue_size=1, latch=True)

        rospy.loginfo("Image undistortion node started on Jetson board.")
        rospy.spin()

    def callback(self, msg):
        try:
            # Decode compressed image to OpenCV format
            np_arr = np.fromstring(msg.data, np.uint8)
            raw_img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            # Undistort the image using loaded calibration
            undistorted_img = cv2.undistort(raw_img, self.camera_matrix, self.dist_coeffs)

            # Convert both to ROS Image messages
            raw_ros_image = self.bridge.cv2_to_imgmsg(raw_img, encoding='bgr8')
            undistorted_ros_image = self.bridge.cv2_to_imgmsg(undistorted_img, encoding='bgr8')

            # Fill and publish the custom message
            out_msg = RawAndUndistorted()
            out_msg.raw_image = raw_ros_image
            out_msg.undistorted_image = undistorted_ros_image

            self.pub.publish(out_msg)
        except Exception as e:
            rospy.logerr("Undistortion failed: %s", str(e))

if __name__ == '__main__':
    UndistortNode()

