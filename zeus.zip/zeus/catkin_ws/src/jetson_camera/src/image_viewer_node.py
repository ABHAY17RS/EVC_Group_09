#!/usr/bin/env python
import rospy
import cv2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from jetson_camera.msg import RawAndUndistorted  # Ensure this matches your package

class ImageViewer:
    def __init__(self):
        rospy.init_node(
            'image_viewer_node',
            anonymous=False,
            xmlrpc_port=45120,
            tcpros_port=45121
        )

        self.bridge = CvBridge()
        rospy.Subscriber('/camera/raw_and_undistorted', RawAndUndistorted, self.callback, queue_size=1)
        rospy.loginfo("Image viewer node started.")
        rospy.spin()

    def callback(self, msg):
        try:
            # Convert both images
            raw_img = self.bridge.imgmsg_to_cv2(msg.raw_image, desired_encoding='bgr8')
            undistorted_img = self.bridge.imgmsg_to_cv2(msg.undistorted_image, desired_encoding='bgr8')

            # Concatenate side by side
            combined = cv2.hconcat([raw_img, undistorted_img])

            # Show the result
            cv2.imshow("Raw (Left) | Undistorted (Right)", combined)
            cv2.waitKey(1)
        except Exception as e:
            rospy.logerr("Viewer failed: %s", str(e))

if __name__ == '__main__':
    ImageViewer()

