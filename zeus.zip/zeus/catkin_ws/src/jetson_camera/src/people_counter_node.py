#!/usr/bin/env python
import rospy
import cv2
import os
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from jetson_camera.msg import RawAndUndistorted
import numpy as np
import datetime
 
class PeopleCounterNode:
    def __init__(self):
        rospy.init_node('people_counter_node', anonymous=False)
 
        self.bridge = CvBridge()
 
        # Load the MobileNet SSD model
        model_path = '/home/jetbot/EVC/workshops/abhay2_w2_g9/models/'
        prototxt_path = os.path.join(model_path, 'MobileNetSSD_deploy.prototxt')
        caffemodel_path = os.path.join(model_path, 'MobileNetSSD_deploy.caffemodel')
        self.net = cv2.dnn.readNetFromCaffe(prototxt_path, caffemodel_path)
 
        self.CLASSES = ["background", "aeroplane", "bicycle", "bird", "boat",
                        "bottle", "bus", "car", "cat", "chair", "cow", "diningtable",
                        "dog", "horse", "motorbike", "person", "pottedplant", "sheep",
                        "sofa", "train", "tvmonitor"]
 
        # Subscribe to the topic from Undistort Node
        rospy.Subscriber('/camera/raw_and_undistorted', RawAndUndistorted, self.callback, queue_size=1)
 
        # Video writer setup
        now = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        self.out_path = '/home/jetbot/EVC/workshops/abhay_w2_g9/people_count_output_%s.avi' % now
        self.fourcc = cv2.VideoWriter_fourcc(*'XVID')
        self.out = None
        self.frame_count = 0
        self.max_frames = 30 * 60  # 30 FPS * 60 seconds
        self.fps = 10  # reduce FPS to make saved video slower/match realtime
 
        rospy.loginfo("People Counter node started.")
        rospy.spin()
 
    def callback(self, msg):
        try:
            raw_img = self.bridge.imgmsg_to_cv2(msg.raw_image, desired_encoding='bgr8')
            undistorted_img = self.bridge.imgmsg_to_cv2(msg.undistorted_image, desired_encoding='bgr8')
 
            (h, w) = undistorted_img.shape[:2]
            blob = cv2.dnn.blobFromImage(cv2.resize(undistorted_img, (300, 300)), 0.007843, (300, 300), 127.5)
            self.net.setInput(blob)
            detections = self.net.forward()
 
            count = 0
            for i in range(detections.shape[2]):
                confidence = detections[0, 0, i, 2]
                if confidence > 0.4:
                    idx = int(detections[0, 0, i, 1])
                    if self.CLASSES[idx] == "person":
                        count += 1
                        box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                        (startX, startY, endX, endY) = box.astype("int")
                        label = "Person: %.2f%%" % (confidence * 100)
                        cv2.rectangle(undistorted_img, (startX, startY), (endX, endY), (0, 255, 0), 2)
                        y = startY - 15 if startY - 15 > 15 else startY + 15
                        cv2.putText(undistorted_img, label, (startX, y),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
 
            cv2.putText(undistorted_img, "Total: %d" % count, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
 
            # Show side-by-side view
            combined = cv2.hconcat([raw_img, undistorted_img])
            cv2.imshow("People Count - Raw | Processed", combined)
            cv2.waitKey(1)
 
            # Write to video
            if self.out is None:
                h_out, w_out = combined.shape[:2]
                self.out = cv2.VideoWriter(self.out_path, self.fourcc, self.fps, (w_out, h_out))
            if self.frame_count < self.max_frames:
                self.out.write(combined)
                self.frame_count += 1
            elif self.frame_count == self.max_frames:
                rospy.loginfo("Recording complete. Video saved.")
                self.out.release()
                self.frame_count += 1
 
        except CvBridgeError as e:
            rospy.logerr("CvBridge Error: %s", str(e))
        except Exception as ex:
            rospy.logerr("Error in people counter callback: %s", str(ex))
 
if __name__ == '__main__':
    PeopleCounterNode()

