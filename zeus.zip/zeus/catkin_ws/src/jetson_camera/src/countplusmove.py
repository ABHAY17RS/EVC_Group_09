#!/usr/bin/env python2
# -*- coding: utf-8 -*-
import cv2
import rospy
import numpy as np
import os
from cv_bridge import CvBridge, CvBridgeError
from jetson_camera.msg import RawAndUndistorted
from std_msgs.msg import String

class PeopleCounterNode:
    def classify_region(self, x, frame_width):
        if x < frame_width / 3:
            return 'left'
        elif x < 2 * frame_width / 3:
            return 'center'
        else:
            return 'right'

    def determine_movement_direction(self, detections, frame_width):
        region_counts = {'left': 0, 'center': 0, 'right': 0}
        for (x, y, w, h) in detections:
            x_center = x + w / 2
            region = self.classify_region(x_center, frame_width)
            region_counts[region] += 1
        return region_counts

    def __init__(self):
        rospy.init_node('people_counter_node')
        self.bridge = CvBridge()
        self.cmd_pub = rospy.Publisher('/jetbot_cmd', String, queue_size=10)

        model_path = "/home/jetbot/EVC/workshops/abhay_w3_g9/models/"
        prototxt_path = os.path.join(model_path, "MobileNetSSD_deploy.prototxt")
        caffemodel_path = os.path.join(model_path, "MobileNetSSD_deploy.caffemodel")
        self.net = cv2.dnn.readNetFromCaffe(prototxt_path, caffemodel_path)
        self.conf_threshold = 0.5

        self.video_writer = None
        self.video_path = "/home/jetbot/EVC/workshops/abhay_w3_g9/people_output.avi"
        self.codec = cv2.VideoWriter_fourcc(*'XVID')
        self.fps = 10

        self.sub = rospy.Subscriber('/camera/raw_and_undistorted', RawAndUndistorted, self.callback)
        rospy.on_shutdown(self.cleanup)
        rospy.loginfo("People Counter Node with live display and video saving initialized!")

    def detect_people(self, frame):
        (h, w) = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 0.007843, (300, 300), 127.5)
        self.net.setInput(blob)
        detections = self.net.forward()

        boxes = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            if confidence > self.conf_threshold:
                class_id = int(detections[0, 0, i, 1])
                if class_id == 15:
                    box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                    (x1, y1, x2, y2) = box.astype("int")
                    boxes.append((x1, y1, x2 - x1, y2 - y1))
        return boxes

    def callback(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg.undistorted_image, "bgr8")
        except CvBridgeError as e:
            rospy.logerr("CvBridge error: {}".format(e))
            return
        except AttributeError as e:
            rospy.logerr("Message format error: {}".format(e))
            return

        if self.video_writer is None:
            height, width = frame.shape[:2]
            self.video_writer = cv2.VideoWriter(self.video_path, self.codec, self.fps, (width, height))

        boxes = self.detect_people(frame)

        for (x, y, w, h) in boxes:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        region_counts = self.determine_movement_direction(boxes, frame.shape[1])

        if sum(region_counts.values()) == 0:
            command = "stay"
        else:
            max_region = max(region_counts, key=region_counts.get)
            if max_region == "left":
                command = "R_45_0.5"
            elif max_region == "right":
                command = "R_-45_0.5"
            else:
                if region_counts["left"] <= region_counts["right"]:
                    command = "R_45_0.5"
                else:
                    command = "R_-45_0.5"

        print("Published command:", command)
        self.cmd_pub.publish(command)

        if command != "stay":
            rospy.sleep(0.5)
            move_cmd = "D_1_0.5"
            print("Published command:", move_cmd)
            self.cmd_pub.publish(move_cmd)

        cv2.putText(frame, "People: {}".format(len(boxes)), (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(frame, "Command: {}".format(command), (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

        cv2.imshow("People Count + Bot Movement", frame)
        cv2.waitKey(1)

        if self.video_writer:
            self.video_writer.write(frame)

    def cleanup(self):
        if self.video_writer:
            self.video_writer.release()
        cv2.destroyAllWindows()
        rospy.loginfo("Video file saved and windows closed.")

if __name__ == '__main__':
    try:
        PeopleCounterNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
    cv2.destroyAllWindows()

