#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import cv2
import rospy
import numpy as np
from cv_bridge import CvBridge, CvBridgeError
from jetson_camera.msg import customImage
from std_msgs.msg import String
from motorScripts.motorDriver import DaguWheelsDriver
from encoderScripts.encoderDriver import WheelEncoderDriver
import math
import time

class CameraSubNode:
    def classify_region(self, x, frame_width):
        if x < frame_width / 3:
            return 'left'
        elif x < 2 * frame_width / 3:
            return 'center'
        else:
            return 'right'

    def determine_movement_direction(self, detections, frame_width):
        region_counts = {'left': 0, 'center': 0, 'right': 0}
        for (x, y, w, h) in detections:
            x_center = x + w / 2
            region = self.classify_region(x_center, frame_width)
            region_counts[region] += 1

        total = sum(region_counts.values())
        if total == 0:
            return 'stay', region_counts
        return min(region_counts, key=region_counts.get), region_counts

    def __init__(self):
        self.initialized = False
        rospy.loginfo("Initializing camera subscriber node with people detection...")
        self.bridge = CvBridge()

        # VideoWriter initialization
        self.video_writer = None
        self.video_writer_undist = None
        self.video_filename = "/home/jetbot/camera_output_motion.avi"
        self.video_filename1 = "/home/jetbot/camera_output_threshold.avi"
        self.fps = 10
        self.codec = cv2.VideoWriter_fourcc(*'XVID')

        # People detector init
        prototxt_path = "/home/jetbot/mobilenet_ssd/MobileNetSSD_deploy.prototxt"
        caffemodel_path = "/home/jetbot/mobilenet_ssd/MobileNetSSD_deploy.caffemodel"
        self.net = cv2.dnn.readNetFromCaffe(prototxt_path, caffemodel_path)
        self.conf_threshold = 0.5

        self.sub_image = rospy.Subscriber(
            "/camera/image_processed",
            customImage,
            self.image_cb,
            buff_size=2**24,
            queue_size=1
        )

        self.encL = WheelEncoderDriver(12)
        self.encR = WheelEncoderDriver(35)
        self.drv  = DaguWheelsDriver()
        self.gain = 1
        self.trim = -0.135
        self.radius = 0.03
        self.ticks_per_rev = 137
        self.V_MAX = 0.7

        self.first_image_received = False
        self.initialized = True
        rospy.loginfo("Camera processing node initialized!")

    def drive_distance(self, cmd):
        self.v  = self.gain * cmd
        self.drv.set_wheels_speed(self.v * (1 - self.trim), self.v * (1 + self.trim))
        Kp = 10
        try:
            for i in range(100):
                ticksL = self.encL._ticks
                ticksR = self.encR._ticks
                error   = ticksL - ticksR
                error_n = error / self.ticks_per_rev
                correction = Kp * error_n * self.v
                v_left  = self.v - correction
                v_right = self.v + correction
                v_left  = max(min(v_left, self.V_MAX), - self.V_MAX)
                v_right = max(min(v_right, self.V_MAX), -self.V_MAX)
                self.drv.set_wheels_speed(v_left, v_right)
                time.sleep(0.01)
        finally:
            self.encL._ticks = 0
            self.encR._ticks = 0
        time.sleep(1)
        self.drv.set_wheels_speed(0, 0)

    def detect_people(self, frame):
        (h, w) = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 0.007843, (300, 300), 127.5)
        self.net.setInput(blob)
        detections = self.net.forward()

        boxes = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            if confidence > self.conf_threshold:
                class_id = int(detections[0, 0, i, 1])
                if class_id == 15:  # person
                    box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                    (x1, y1, x2, y2) = box.astype("int")
                    boxes.append((x1, y1, x2 - x1, y2 - y1))
        return boxes

    def image_cb(self, data):
        if not self.initialized:
            return
        try:
            cv2_image = cv2.imdecode(np.frombuffer(data.data_undistorted, np.uint8), cv2.IMREAD_COLOR)
            default = cv2.imdecode(np.frombuffer(data.data, np.uint8), cv2.IMREAD_COLOR)

            if not self.first_image_received:
                self.first_image_received = True
                rospy.loginfo("First image received from publisher.")
                height, width, _ = cv2_image.shape
                self.video_writer = cv2.VideoWriter(self.video_filename, self.codec, self.fps, (width, height))
                self.video_writer_undist = cv2.VideoWriter(self.video_filename1, self.codec, self.fps, (width, height))
                return

            self.process_frames(default, cv2_image)

        except CvBridgeError as err:
            rospy.logerr("Error converting image: {}".format(err))
        except Exception as e:
            rospy.logerr("Error in processing frame: {}".format(e))

    def command_bot(self, direction):
        if direction == 'left':
            self.drv.rotate(-90)
        elif direction == 'right':
            self.drv.rotate(90)
        elif direction == 'center':
            self.drive_distance(0.75)

    def process_frames(self, raw_frame, undistorted_frame):
        boxes = self.detect_people(undistorted_frame)
        for (x, y, w, h) in boxes:
            cv2.rectangle(undistorted_frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        direction, region_counts = self.determine_movement_direction(boxes, undistorted_frame.shape[1])
        if direction != 'stay':
            self.command_bot(direction)

        if self.video_writer:
            self.video_writer.write(raw_frame)
        if self.video_writer_undist:
            self.video_writer_undist.write(undistorted_frame)

    def cleanup(self):
        if self.video_writer:
            self.video_writer.release()
        if self.video_writer_undist:
            self.video_writer_undist.release()
        rospy.loginfo("Video files saved as '{}' and '{}'".format(
            self.video_filename, self.video_filename1))
        cv2.destroyAllWindows()

if __name__ == "__main__":
    rospy.init_node('camera_sub_node', anonymous=False)
    camera_node = CameraSubNode()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        rospy.loginfo("Shutting down image viewer node.")
    finally:
        camera_node.cleanup()

