#!/usr/bin/env python

import rospy
from sensor_msgs.msg import CompressedImage
import numpy as np
import cv2
import os

class CompressedImageSubscriber:
    def __init__(self):
        rospy.init_node('capture_node', anonymous=True)
        self.image_sub = rospy.Subscriber('/camera/image_raw', CompressedImage, self.callback)

        self.save_dir = "/home/jetbot/EVC/workshops/abhay_w2_g9/calibration_images"
        if not os.path.exists(self.save_dir):
            os.makedirs(self.save_dir)

        self.image_count = 0
        self.max_images = 10

        rospy.loginfo("Compressed Image Subscriber initialized. Waiting for images...")
        rospy.spin()

    def callback(self, msg):
        try:
            np_arr = np.frombuffer(msg.data, np.uint8)
            cv_image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        except Exception as e:
            rospy.logerr("Image decode error: {}".format(e))
            return

        if self.image_count < self.max_images:
            filename = os.path.join(self.save_dir, "imd{:02d}.jpg".format(self.image_count + 1))
            cv2.imwrite(filename, cv_image)
            rospy.loginfo("Saved image: {}".format(filename))
            self.image_count += 1

        cv2.imshow("Compressed Image View", cv_image)
        cv2.waitKey(1)

if __name__ == '__main__':
    try:
        CompressedImageSubscriber()
    except rospy.ROSInterruptException:
        pass

