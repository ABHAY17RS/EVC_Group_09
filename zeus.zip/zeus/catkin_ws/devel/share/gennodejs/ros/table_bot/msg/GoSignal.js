// Auto-generated. Do not edit!

// (in-package table_bot.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class GoSignal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.job_id = null;
    }
    else {
      if (initObj.hasOwnProperty('job_id')) {
        this.job_id = initObj.job_id
      }
      else {
        this.job_id = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GoSignal
    // Serialize message field [job_id]
    bufferOffset = _serializer.int32(obj.job_id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GoSignal
    let len;
    let data = new GoSignal(null);
    // Deserialize message field [job_id]
    data.job_id = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'table_bot/GoSignal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9cdb9e8b6886d35c53a1e7a54c2a35e2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Signals completion of a task
    int32 job_id
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GoSignal(null);
    if (msg.job_id !== undefined) {
      resolved.job_id = msg.job_id;
    }
    else {
      resolved.job_id = 0
    }

    return resolved;
    }
};

module.exports = GoSignal;
