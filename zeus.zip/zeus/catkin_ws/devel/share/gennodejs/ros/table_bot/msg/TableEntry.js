// Auto-generated. Do not edit!

// (in-package table_bot.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TableEntry {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.routine_id = null;
      this.job_id = null;
      this.table_number = null;
      this.vacancy = null;
    }
    else {
      if (initObj.hasOwnProperty('routine_id')) {
        this.routine_id = initObj.routine_id
      }
      else {
        this.routine_id = '';
      }
      if (initObj.hasOwnProperty('job_id')) {
        this.job_id = initObj.job_id
      }
      else {
        this.job_id = 0;
      }
      if (initObj.hasOwnProperty('table_number')) {
        this.table_number = initObj.table_number
      }
      else {
        this.table_number = 0;
      }
      if (initObj.hasOwnProperty('vacancy')) {
        this.vacancy = initObj.vacancy
      }
      else {
        this.vacancy = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TableEntry
    // Serialize message field [routine_id]
    bufferOffset = _serializer.string(obj.routine_id, buffer, bufferOffset);
    // Serialize message field [job_id]
    bufferOffset = _serializer.int32(obj.job_id, buffer, bufferOffset);
    // Serialize message field [table_number]
    bufferOffset = _serializer.int32(obj.table_number, buffer, bufferOffset);
    // Serialize message field [vacancy]
    bufferOffset = _serializer.bool(obj.vacancy, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TableEntry
    let len;
    let data = new TableEntry(null);
    // Deserialize message field [routine_id]
    data.routine_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [job_id]
    data.job_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [table_number]
    data.table_number = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [vacancy]
    data.vacancy = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.routine_id.length;
    return length + 13;
  }

  static datatype() {
    // Returns string type for a message object
    return 'table_bot/TableEntry';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c38c74c2a7d17e2c08ce19a944ce66d9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # A single “job” entry from NODE5
    string routine_id      # "R1" or "R2"
    int32 job_id
    int32 table_number    # for R1: unused on publish; for R2: unused on publish
    bool vacancy          # for R1: true=table vacant; for R2: true=vacant flag
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TableEntry(null);
    if (msg.routine_id !== undefined) {
      resolved.routine_id = msg.routine_id;
    }
    else {
      resolved.routine_id = ''
    }

    if (msg.job_id !== undefined) {
      resolved.job_id = msg.job_id;
    }
    else {
      resolved.job_id = 0
    }

    if (msg.table_number !== undefined) {
      resolved.table_number = msg.table_number;
    }
    else {
      resolved.table_number = 0
    }

    if (msg.vacancy !== undefined) {
      resolved.vacancy = msg.vacancy;
    }
    else {
      resolved.vacancy = false
    }

    return resolved;
    }
};

module.exports = TableEntry;
