
"use strict";

let TableEntry = require('./TableEntry.js');
let GoSignal = require('./GoSignal.js');

module.exports = {
  TableEntry: TableEntry,
  GoSignal: GoSignal,
};
